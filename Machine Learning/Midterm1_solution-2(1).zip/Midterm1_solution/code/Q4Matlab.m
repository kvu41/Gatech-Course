clear; 
%%%%%   Part 1     %%%%%%%%%%%
%%%%% Subject 1  %%%%%%%%%%%
for i = 1:10
    I = imread(['subject01.',num2str(i),'.gif']);
    X = I';
    X01(:,i) = double(X(:));
end
[m, n] = size(I);

stdX01 = std(X01, 1, 1); 
X01 = X01 * diag(1./stdX01); 

Mean01 = mean(X01);
X01 = X01 - Mean01;
C = X01'*X01;
k = 6;
[Q,S] = eigs(C,k);
eigenfaces01 = X01*Q; 
figure;
for ii = 1:k
    subplot(2,3,ii)
    diseigface = reshape(eigenfaces01(:,ii),n,m);
    imshow(diseigface')
    title(['Subject 01 Eigenfaces',num2str(ii)])
    hold
end

%%%%% Subject 14  %%%%%%%%%%%
for i = 1:10
    I = imread(['subject14.',num2str(i),'.gif']);
    X = I';
    X14(:,i) = double(X(:));
end
[m, n] = size(I);
stdX14 = std(X14, 1, 1); 
X14 = X14 * diag(1./stdX14); 
Mean14 = mean(X14);
X14 = X14 - Mean14;
C = X14'*X14;
k = 6;
[Q,S] = eigs(C,k);
eigenfaces14 = X14*Q; 
figure;
for ii = 1:k
    subplot(2,3,ii)
    diseigface = reshape(eigenfaces14(:,ii),n,m);
    imshow(diseigface')
    title(['Subject 14 Eigenfaces',num2str(ii)])
    hold
end


%%%%    Part 2   %%%%%%%
I = imread('subject01-test.gif');
Xt = I';
Xtest01 = double(Xt(:));
stdX01 = std(Xtest01, 1, 1); 
Xtest01 = Xtest01 * diag(1./stdX01); 
MeanXtest01 = mean(Xtest01);
Xtest01 = Xtest01 - MeanXtest01;

I = imread('subject14-test.gif');
Xt = I';
Xtest14 = double(Xt(:));
stdX14 = std(Xtest14, 1, 1); 
Xtest14 = Xtest14 * diag(1./stdX14); 
MeanXtest14 = mean(Xtest14);
Xtest14 = Xtest14 - MeanXtest14;

corr0101 = (eigenfaces01(:,1)'*Xtest01)/ (norm(eigenfaces01(:,1)) * norm(Xtest01) )
corr1401 = (eigenfaces14(:,1)'*Xtest01)/ (norm(eigenfaces14(:,1)) * norm(Xtest01) )
corr0114 = (eigenfaces01(:,1)'*Xtest14)/ (norm(eigenfaces01(:,1)) * norm(Xtest14) )
corr1414 = (eigenfaces14(:,1)'*Xtest14)/ (norm(eigenfaces14(:,1)) * norm(Xtest14) )

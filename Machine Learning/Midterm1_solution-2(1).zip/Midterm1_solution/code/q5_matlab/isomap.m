load('isomap.mat');
images = transpose(images);
[n,d] = size(images);
Distance = zeros([n,n]);
for i = 1:n
    for j = i:n
        Distance(i,j) = sqrt(sum((images(i,:) - images(j,:)).^2));    
    end
    for j = 1:i-1
        Distance(i,j) = Distance(j,i);
    end
end

A = zeros([n,n]);
figure()
imagesc(A);
colormap(gray);
colorbar;
for i =1:n
    threshold = quantile(Distance(i,:), 101/600);
    A(i,:) = Distance(i,:) < threshold;
end

W = A.*Distance + 99999*(1-A);
for i = 1:n
    W(i,i) = 0;
end

D = Matrix_D(W);

csvwrite('D.csv', D);
one = ones([n,1]);
I = eye(n);
H = I - one*one.'/n;
C = -H*D.^2*H/(2*n);
[V,D] = eig(C);
eig_val = diag(D);
[d,index] = sort(-eig_val);
Z = V(:,index(1:2));
scatter(Z(:,1), Z(:,2));
[i,index] = sort(-Z(:,2));
for i = 1:3
    figure()
    imagesc(reshape(images(index(i),:), 64, 64));
    colormap(gray);
    colorbar;
end
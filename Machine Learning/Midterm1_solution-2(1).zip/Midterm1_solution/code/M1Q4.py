#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 17:36:53 2019

@author: helenlu
"""

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import scipy as sp
import glob
from sklearn.decomposition import PCA
from numpy import linalg as LA
import scipy.sparse as sparse

# Image down-sampling by factor 4
# Throw away every other column and row

def form_face_matrix(filename):
    X = []
    for name in glob.glob(filename):
        im = mpimg.imread(name)
        ind1 = np.arange(0,im.shape[0],2)
        ind2 = np.arange(0,im.shape[1],2)
        im = im[ind1,:]
        im = im[:,ind2]
        X.append(im.reshape(1,len(ind1) * len(ind2)))
#        X_np = np.concatenate(X, axis=0)
    return X
   
# get array X for subject 14
S14 = form_face_matrix("subject14.*.gif")
S14 = np.concatenate(S14,axis = 0)
mean14 = np.mean(S14,axis = 0)
S14 = S14 - mean14

# get array X for subject 01
S01 = form_face_matrix("subject01.*.gif")
S01 = np.concatenate(S01,axis = 0)
mean01 = np.mean(S01,axis = 0)
S01 = S01 - mean01

n = S14.shape[1]

# get XX^T
XX14 = np.dot(S14, S14.T)
XX01 = np.dot(S01, S01.T)

print(len(XX14))
w14,v14 = sparse.linalg.eigs(XX14, k=6, which='LM')
w01,v01 = sparse.linalg.eigs(XX01, k=6, which='LM')

Eig_faces14 = np.zeros((n,6))
Eig_faces01 = np.zeros((n,6))

for i in range(6):
    Eig_faces14[:,i] = np.dot(S14.T,v14[:,i])
    Eig_faces01[:,i] = np.dot(S01.T,v01[:,i])
    
    im = np.reshape(Eig_faces14[:,i],(122,160))
    plt.imshow(im,cmap = 'gray')
    plt.show()
    
    im = np.reshape(Eig_faces01[:,i],(122,160))
    plt.imshow(im,cmap = 'gray')
    plt.show()
    
# Second Task
test14 = form_face_matrix("subject14-test.gif")
test14 = np.concatenate(test14,axis = 0)
test14 = test14 - mean14

test01 = form_face_matrix("subject01-test.gif")
test01 = np.concatenate(test01,axis = 0)
test01 = test01 - mean01

# take top eigenface of subject 01 and subject 14
u01 = Eig_faces01[:,0].T
u14 = Eig_faces14[:,0].T

# report scores
score_1_1 = abs(u01 @ test01.T)  # project subject 1 on u01
score_14_1 = abs(u01 @ test14.T)  # project subject 14 on u01

score_1_14 = abs(u14 @ test01.T) # project subject 1 on u14
score_14_14 = abs(u14 @ test14.T) # project subject 14 on u14

print(score_1_1)
print(score_1_14)
print(score_14_1)
print(score_14_14)
print(score_1_1 - score_14_1)
print(score_14_14 - score_1_14)

###############################


import numpy as np
import matplotlib.pyplot as plt
#from Matrix_D import *
#import networkx as nx

# Define Euclidean Distance
def distance(x,y):
    return np.sqrt(np.sum((x-y)**2))

# Loading Data
images = np.loadtxt('isomap.csv', delimiter = ',')
(d, n) = np.shape(images)
print('Dimension:',d)
print('# Data points:', n)

# Generate Matrix for Similarity Graph
G = np.zeros([n,n])
for i in range(n):
    for j in range(n):
        G[i,j] = distance(images[:,i], images[:,j])


for i in range(n):
    p = np.percentile(G[i,:], 10100/n) # Find the threshold for the distrance of 100 nearest neighbor
    for j in range(n):
        if G[i,j] > p:
            G[i,j] = 99999.9 # Assign large value for distance greater than the threshold

np.savetxt('W_euclidean.csv', G)

# Plot the Adjacency Matrix by Intensity
plt.figure()
plt.imshow(G,cmap=plt.get_cmap('gray'))
plt.savefig('Adjacency.png', dpi=600)

W = np.loadtxt('W_euclidean.csv')

from Matrix_D import *
D = Matrix_D(W)
print('D:', D)
np.savetxt('D_euclidean.csv', D)

D = np.loadtxt('D_euclidean.csv')
D = (D + D.T)/2
#eig_val, eig_vec = np.linalg.eig(D)
#print(eig_val)
print(np.max(D-D.T))
# Compute Matrix C
ones = np.ones([n,1])
H = np.eye(n) - 1/n*ones.dot(ones.T)
C = -H.dot(D**2).dot(H)/(2*n)
#print(np.max(C-C.T))
eig_val, eig_vec = np.linalg.eig(C)
#print(eig_val)
index = np.argsort(-eig_val) # Sort eigenvalue from large to small
print(eig_val[index[0:2]])
Z = eig_vec[:,index[0:2]].dot(np.diag(1/np.sqrt(eig_val[index[0:2]])))
print(np.shape(Z))

index = np.argsort(Z[:,0])[0:3]
img_1 = np.reshape(images[:,index[0]], [64, -1])
img_2 = np.reshape(images[:,index[1]], [64, -1])
img_3 = np.reshape(images[:, index[2]], [64, -1])
for i in range(3):
    plt.figure()
    plt.title('Image_'+str(i+1))
    plt.imshow(eval('img_'+str(i+1)), cmap=plt.get_cmap('gray'))
    plt.savefig('image_'+str(i+1)+'.png', dpi = 600)

# Plot Embedding
plt.figure()
plt.scatter(Z[:,0], Z[:,1], s = 5)
plt.savefig('embedding_euclidean.png', dpi=600)





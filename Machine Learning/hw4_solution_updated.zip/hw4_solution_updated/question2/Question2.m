clear;
% MATLAB CODE FOR HOMEWORK 4 QUESTION 2
% ======== Divorce Data ============

% === Part one ===
data1 = csvread('q3.csv');
y = data1(:, 55);
X = data1(:, 1:54);
y = categorical(y);

% randomly split data to 80% and 20%

shape = size(data1);
train_size = shape(1) * .8;

k = randperm(size(data1,1));
x_train = X(k(1:train_size ), :);
x_test = X(k(train_size+1:shape(1)), :);
y_train = y(k(1:train_size), :);
y_test = y(k(train_size + 1:shape(1)), :);


% Tune parameters using cross validation
% I only implemented it for KNN, same idea could also be applied
% to other models.
% Reference: https://www.mathworks.com/help/bioinfo/ref/crossvalind.html


% Build KNN classifier
% Cross validation for parameter tuning
indices = crossvalind('Kfold',y_train,10);

k = 5:1:15;
len = size(k);
accuracy_final = zeros(1, len(2));
for k = 5:1:15
    accuracies = zeros(1,10);
    for i = 1:10
        test = (indices == i); 
        train = ~test;
        temp_model = fitcknn(x_train(train,:),y_train(train,:), 'NumNeighbors',k);
        pred = predict(temp_model, x_train(test,: ));
        total_obsv = size(pred);
        accuracies(i) = sum(pred == y_train(test,:))/total_obsv(1);
    end
    accuracy_final(k-4) = mean(accuracies);
end
figure(1);
plot(5:1:15, accuracy_final);
title('KNN model accuracy with different k');
xlabel('k'); 
ylabel('accuracy')

% use the full training dataset to train a new model;
model_KNN = fitcknn(x_train, y_train,'NumNeighbors',5);

% Build Logistic regressioin classifier
model_reg = fitclinear(x_train, y_train, 'Learner', 'logistic');

% Build naive bayes model
model_naive = fitcnb(x_train, y_train);

[test_size, a] = size(y_test);

pred_knn = predict(model_KNN, x_test);
pred_reg = predict(model_reg, x_test);
pred_nb = predict(model_naive, x_test);

accuracy_knn = sum(pred_knn == y_test)/test_size;
accuracy_reg = sum(pred_reg == y_test)/test_size;
accuracy_nb = sum(pred_nb == y_test)/test_size;

% === Part two ===

% Use the first two features:
x_train_new =  x_train(:,(1:2));
x_test_new = x_test(:, (1:2));

% Build KNN classifier
model_KNN2 = fitcknn(x_train_new, y_train,'NumNeighbors',5,'Standardize',1);

% Build Logistic regressioin classifier
model_reg2 = fitclinear(x_train_new, y_train, 'Learner', 'logistic');

% Build naive bayes model
model_naive2 = fitcnb(x_train_new, y_train);

% plot decision boundary for model using only 2 features
classifier_name = {'Naive Bayes','Logistic Regression','Nearest Neighbor'};
classifier{1} = model_naive2;
classifier{2} = model_reg2;
classifier{3} = model_KNN2;

figure(2);
x1range = min(x_train_new(:,1)):.01:max(x_train_new(:,1));
x2range = min(x_train_new(:,2)):.01:max(x_train_new(:,2));

[xx1, xx2] = meshgrid(x1range,x2range);
XGrid = [xx1(:) xx2(:)];

for i = 1:numel(classifier)
   predictedDivorce = predict(classifier{i}, XGrid);
   subplot(2,2,i);
   gscatter(xx1(:), xx2(:), predictedDivorce,'rgb');
   title(classifier_name{i})
   legend off, axis tight
end

legend(categories(y_train),'Location',[0.35,0.01,0.35,0.05],'Orientation','Horizontal')


% ======= MNIST Data =======

% === Part one ===

load data
load label
num2 = data(:, find(trueLabel==2))';
num6 = data(:, find(trueLabel==6))';
% Random split

y_mnist = transpose(horzcat(trueLabel(trueLabel == 2),trueLabel(trueLabel == 6)));
X_mnist = vertcat(num2, num6);

shape_mnist = size(X_mnist);
train_size = shape_mnist(1) * .8;


k = randperm(size(X_mnist,1));
x_train_mnist = X_mnist(k(1:train_size), :);
x_test_mnist = X_mnist(k(train_size+1:shape_mnist(1)), :);
y_train_mnist = y_mnist(k(1:train_size), :);
y_test_mnist = y_mnist(k(train_size + 1:shape_mnist(1)), :);

[test_size, a] = size(y_test_mnist);

% Build KNN classifier
model_KNN_mnist = fitcknn(x_train_mnist, y_train_mnist,'NumNeighbors',5);

% Build Logistic regressioin classifier
model_reg_mnist = fitclinear(x_train_mnist, y_train_mnist, 'Learner', 'logistic');

% Build naive bayes model
x_train_nb = x_train_mnist(:,~var(x_train_mnist(y_train_mnist==2,:)) == 0);
x_test_nb = x_test_mnist(:,~var(x_train_mnist(y_train_mnist==2,:)) == 0);
x_train_nb = x_train_nb(:,~var(x_train_nb(y_train_mnist==6,:)) == 0);
x_test_nb = x_test_nb(:,~var(x_train_nb(y_train_mnist==6,:)) == 0);

model_naive_mnist = fitcnb(x_train_nb, y_train_mnist);

pred_knn = predict(model_KNN_mnist, x_test_mnist);
pred_reg = predict(model_reg_mnist, x_test_mnist);
pred_nb = predict(model_naive_mnist, x_test_nb);

accuracy_knn = sum(pred_knn == y_test_mnist)/test_size;
accuracy_reg = sum(pred_reg == y_test_mnist)/test_size;
accuracy_nb = sum(pred_nb == y_test_mnist)/test_size;

